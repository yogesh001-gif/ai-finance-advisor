# Security Policy

## Supported Versions
We release security updates for the latest version of the project.

## Reporting a Vulnerability
If you discover a security vulnerability, please email yahlawat1980@gmail.com with details. Do not open public issues for security problems.

We will respond as quickly as possible and keep you informed of the fix progress.
